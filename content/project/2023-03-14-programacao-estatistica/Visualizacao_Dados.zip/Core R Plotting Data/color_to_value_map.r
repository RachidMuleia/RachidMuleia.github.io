map.colours <- function (values,palette) {

  range <- range(values)

  proportion <- ((values-range[1])/(range[2]-range[1]))
  index <- round ((length(palette)-1)*proportion)+1
  return (palette[index])
}